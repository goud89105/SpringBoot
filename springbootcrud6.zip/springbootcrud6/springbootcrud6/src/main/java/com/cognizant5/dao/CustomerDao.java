package com.cognizant5.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant5.jpa.CustomerRepository;
import com.cognizant5.model.Customer;

@Repository
public class CustomerDao {
	
	@Autowired
	CustomerRepository customerRepository;
 
	public List<Customer> getCustomers()
	{
		return customerRepository.findAll();
		
	}
	
	 public void insert(Customer customer)
	 {
		 customerRepository.save(customer); 
	 }
	 
	 public void deleteRecord(Integer id)
	 {
		 customerRepository.deleteById(id);
		 
		
	 }
	 
	 public void updateRecord(Integer id,Customer customer)
	 {
		 Customer customer1=customerRepository.findById(id).orElseThrow(); 
		 customer1.setCustid(customer.getCustid());
		 customer1.setCustname(customer.getCustname());
		 customer1.setCustaddress(customer.getCustaddress());
		 
		 customerRepository.save(customer1);
	 }
}
