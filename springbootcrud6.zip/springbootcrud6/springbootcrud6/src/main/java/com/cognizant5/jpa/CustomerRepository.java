package com.cognizant5.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant5.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

}
