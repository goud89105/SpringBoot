package com.cognizant5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootcrud6Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootcrud6Application.class, args);
	}

}
