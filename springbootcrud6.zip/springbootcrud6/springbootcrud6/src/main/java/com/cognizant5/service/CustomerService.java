package com.cognizant5.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant5.dao.CustomerDao;
import com.cognizant5.model.Customer;

@Service
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	
 public List<Customer> getCustomers()
 {
	return customerDao.getCustomers();
	 
 }
 
 public void insert(Customer customer)
 {
	 customerDao.insert(customer); 
 }
 
 
 public void deleteRecord(Integer id)
 {
	 customerDao.deleteRecord(id); 
 }
 
 public void updateRecord(Integer id,Customer customer)
 {
	 customerDao.updateRecord(id, customer); 
 }
}
