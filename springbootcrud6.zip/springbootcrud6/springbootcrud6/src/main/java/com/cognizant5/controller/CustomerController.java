package com.cognizant5.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant5.model.Customer;
import com.cognizant5.service.CustomerService;

@RestController
public class CustomerController {
	@Autowired
	CustomerService customerService;

	@GetMapping("/fetchdata")
	public List<Customer> getCustomers()
	{
		return customerService.getCustomers();
		
	}
	@PostMapping("/save")
	public void insert(@RequestBody Customer customer)
	{
		customerService.insert(customer);
	}
	@DeleteMapping(value="/deleterecord/{id}")
	public void deleteRecord(@PathVariable Integer id)
	{
		customerService.deleteRecord(id);
		
	}
	@PutMapping(value="/deleterecord/{id}")
	public void updateRecord(@PathVariable Integer id,@RequestBody Customer customer)
	{
		customerService.updateRecord(id, customer);
	}

}
